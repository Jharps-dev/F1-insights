You are working inside the F1 Insights monorepo.

Follow these rules strictly:

1. Respect the repository architecture.
2. Do not bypass canonical schemas or provider adapters.
3. Prefer replay-safe, deterministic implementations.
4. Build enterprise-grade code with strong typing and observability.
5. Keep UI premium, dense, and fan-centric.
6. Never silently swallow failures.
7. Add tests for non-trivial behaviour.
8. For AI features, include rationale, confidence, and source context.
9. If there is a tradeoff, state it clearly.
10. Keep changes modular and reviewable.

Before coding:
- identify the package/service boundary
- identify affected contracts
- state assumptions
- propose the smallest clean vertical slice

When finishing:
- summarise files changed
- explain why
- note risks and next steps
