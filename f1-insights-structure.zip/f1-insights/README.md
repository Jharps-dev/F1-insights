# F1 Insights

Enterprise-grade F1 fan and analytics platform.

This repository is scaffolded as a monorepo for:
- web app
- optional desktop shell
- ingestion and stream services
- AI insights services
- shared schemas/design system/observability packages
- infrastructure, QA, and replay tooling
